(() => {
  "use strict";
  async function unzipEntries(buf) {
    const b = new Uint8Array(buf), d = new DataView(b.buffer), out = {};
    const td = new TextDecoder("utf-8"); let p = 0;
    while (p + 30 <= b.length && d.getUint32(p, true) === 0x04034b50) {
      const method = d.getUint16(p + 8, true), size = d.getUint32(p + 18, true);
      const nl = d.getUint16(p + 26, true), el = d.getUint16(p + 28, true);
      const name = td.decode(b.slice(p + 30, p + 30 + nl));
      const start = p + 30 + nl + el, comp = b.slice(start, start + size);
      if (method === 0) out[name] = comp;
      else if (method === 8) {
        const ds = new DecompressionStream("deflate-raw");
        out[name] = new Uint8Array(await new Response(new Blob([comp]).stream().pipeThrough(ds)).arrayBuffer());
      } else throw new Error("Format XLSX tidak didukung.");
      p = start + size;
    }
    return out;
  }
  const xml = b => new TextDecoder("utf-8").decode(b || new Uint8Array());
  const un = s => String(s).replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'");
  const colNum = s => { let n=0; for(const c of s) n=n*26+c.charCodeAt(0)-64; return n-1; };
  function sharedStrings(x) {
    const arr=[];
    for(const m of x.matchAll(/<si\b[\s\S]*?<\/si>/g)) {
      let t=""; for(const q of m[0].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)) t+=un(q[1]); arr.push(t);
    }
    return arr;
  }
  function sheetRows(x, ss) {
    const out=[];
    for(const rm of x.matchAll(/<row\b[\s\S]*?<\/row>/g)) {
      const r=[];
      for(const cm of rm[0].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
        const a=cm[1], body=cm[2], ref=/\br="([A-Z]+)\d+"/.exec(a); if(!ref) continue;
        const vm=/<v\b[^>]*>([\s\S]*?)<\/v>/.exec(body);
        const im=/<is\b[\s\S]*?<t\b[^>]*>([\s\S]*?)<\/t>[\s\S]*?<\/is>/.exec(body);
        let v=vm?un(vm[1]):(im?un(im[1]):"");
        if(/\bt="s"/.test(a)) v=ss[Number(v)] ?? v;
        r[colNum(ref[1])] = v;
      }
      out.push(r);
    }
    return out;
  }
  async function parseXlsxFile(file) {
    const e=await unzipEntries(await file.arrayBuffer());
    const wb=xml(e["xl/workbook.xml"]), rels=xml(e["xl/_rels/workbook.xml.rels"]);
    const ss=e["xl/sharedStrings.xml"]?sharedStrings(xml(e["xl/sharedStrings.xml"])):[];
    const rid=/<sheet\b[^>]*r:id="([^"]+)"/.exec(wb)?.[1];
    if(!rid) throw new Error("Worksheet tidak ditemukan.");
    const target=new RegExp('<Relationship\\b[^>]*Id="'+rid+'"[^>]*Target="([^"]+)"').exec(rels)?.[1];
    if(!target) throw new Error("Lokasi worksheet tidak ditemukan.");
    const path=target.startsWith("/")?target.slice(1):"xl/"+target.replace(/^\.?\//,"");
    const rows=sheetRows(xml(e[path]),ss);
    // File export ini punya 4 baris informasi di atas tabel. Cari header secara dinamis.
    const headerIndex=rows.findIndex(r=>r.some(v=>String(v??"").trim().toUpperCase()==="TANGGAL"));
    if(headerIndex<0) throw new Error("Header TANGGAL tidak ditemukan.");
    const headers=(rows[headerIndex]||[]).map(v=>String(v??"").trim());
    const data=rows.slice(headerIndex+1).map(r=>{
      const o={}; headers.forEach((h,i)=>{if(h)o[h]=String(r[i]??"").trim();}); return o;
    }).filter(o=>String(o["KODE TIKET"]||"").trim());
    return {headers, rows:data};
  }
  window.SYAFIRA_XLSX={parseXlsxFile};
})();
