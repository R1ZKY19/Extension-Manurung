(() => {
  console.log("BET LOGGER: content.js jalan");

  // Ambil kode tiket dari URL (?invoice=...)
  function getKodeTiketFromUrl() {
    try {
      const u = new URL(location.href);
      const inv = u.searchParams.get('invoice') || '';
      return inv.split('-')[0] || '';
    } catch { return ''; }
  }

  // ================= WAIT HELPER =================
  function waitFor(selector, timeout = 3000) {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector(selector);
      if (existing) return resolve(existing);

      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });

      observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });

      setTimeout(() => {
        observer.disconnect();
        reject("Timeout waiting: " + selector);
      }, timeout);
    });
  }

  // ================= WAIT PAYOUT CHANGE =================
  function waitForPayoutChange(previousText = "", timeout = 1200) {
    return new Promise((resolve) => {
      const observer = new MutationObserver(() => {
        const current = [...document.querySelectorAll(".payout-item-title")]
          .pop()?.innerText?.trim();

        if (current && current !== previousText) {
          clearTimeout(timer);
          observer.disconnect();
          resolve();
        }
      });

      const timer = setTimeout(() => {
        observer.disconnect();
        resolve();
      }, timeout);

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    });
  }

  // ================= WAIT BET RESULT STABLE =================
  // Tunggu hingga jumlah .bet-result-item tidak berubah selama `stableMs`
  // Mencegah salah hitung saat internet lambat dan elemen belum semua ter-render
  function waitForBetResultStable(timeout = 8000, stableMs = 600) {
    return new Promise((resolve) => {
      const startTime = Date.now();
      let lastCount = -1;
      let stableStart = null;

      function check() {
        if (Date.now() - startTime >= timeout) {
          resolve(); // timeout — lanjut dengan data seadanya
          return;
        }

        const current = document.querySelectorAll(".bet-result-item").length;

        if (current !== lastCount) {
          // Jumlah berubah, reset timer stabilitas
          lastCount = current;
          stableStart = Date.now();
        } else if (stableStart !== null && Date.now() - stableStart >= stableMs) {
          resolve(); // Sudah stabil selama stableMs, aman dihitung
          return;
        }

        setTimeout(check, 100);
      }

      check();
    });
  }

  // ================= MAIN =================
  async function runWhenReady() {
    try {
      // Jangan anggap pengecekan selesai hanya karena halaman Bet Details sudah terbuka.
      // Kita tunggu sampai BET, PROFIT, dan PAYOUT benar-benar muncul, tetapi tetap
      // mengirim snapshot setelah timeout agar dashboard bisa memberi hasil TIDAK SESUAI.
      function t(sel) {
        return document.querySelector(sel)?.innerText.trim() || "";
      }

      function formatThreeDecimal(str) {
        if (!str) return "";
        if (!str.includes(",")) {
          str = str.replace(/\.(\d{1,2})$/, ",$1");
        }
        if (!str.includes(",")) return str + ",000";
        const parts = str.split(",");
        let decimals = parts[1] || "";
        while (decimals.length < 3) decimals += "0";
        return parts[0] + "," + decimals.slice(0, 3);
      }

      const data = {
        transaction: t(".header-transaction .header-item-value"),
        bet: formatThreeDecimal(t(".header-item:nth-child(2) .header-item-value")),
        profit: formatThreeDecimal(t(".header-item:nth-child(3) .header-item-value")),
        symbols: [],
        payouts: []
      };

      // Tunggu data utama maksimal 10 detik. Kalau salah satu tidak muncul,
      // tetap kirim data yang ada supaya status final menjadi TIDAK SESUAI.
      const dataDeadline = Date.now() + 10000;
      while (Date.now() < dataDeadline) {
        data.transaction = t(".header-transaction .header-item-value");
        data.bet = formatThreeDecimal(t(".header-item:nth-child(2) .header-item-value"));
        data.profit = formatThreeDecimal(t(".header-item:nth-child(3) .header-item-value"));
        const payoutEls = [...document.querySelectorAll(".payout-item-title")]
          .map(el => el.innerText?.trim() || "").filter(Boolean);
        if (data.bet && data.profit && payoutEls.length) break;
        await new Promise(r => setTimeout(r, 200));
      }

      // ================= SYMBOL =================
      document.querySelectorAll(".bet-result-column").forEach((col, i) => {
        const syms = [...col.querySelectorAll(".symbol")]
          .map(s => s.className.replace("sprite-symbol symbol ", ""))
          .filter(Boolean);

        if (syms.length)
          data.symbols.push(`C${i + 1}: ${syms.join(", ")}`);
      });

      // ================= COLLECT PAYOUT =================
      // Ambil SEMUA payout yang tampil. Versi lama hanya mengambil
      // scatter 3-5 dan hanya dari round terakhir, sehingga banyak payout hilang.
      function collectAllPayouts() {
        const found = [];
        document.querySelectorAll(".payout-item-title").forEach(title => {
          const text = title.innerText?.trim() || "";
          if (!text) return;
          // HANYA payout resmi X3/X4/X5 yang boleh masuk dashboard.
          // X2 atau angka lain di elemen payout diabaikan.
          const matches = text.match(/\bx\s*(3|4|5)\b/gi);
          if (matches?.length) {
            matches.forEach(m => {
              const value = "X" + m.replace(/[^345]/g, "");
              if (!found.includes(value)) found.push(value);
            });
          }
        });
        const existing = new Set(data.payouts);
        found.forEach(value => {
          if (!existing.has(value)) {
            data.payouts.push(value);
            existing.add(value);
          }
        });
      }

      async function collectPayout() {
        const roundTitle = document.querySelector(".result-detail-item.round-title");

        // ===== TIDAK ADA ROUND =====
        if (!roundTitle) {
          await waitFor(".payout-item-title");
          collectAllPayouts();
          return;
        }

        // ===== ADA ROUND =====
        let totalRounds = 1;
        const match = roundTitle.innerText.trim().match(/Round\s+\d+\/(\d+)/i);
        if (match) totalRounds = parseInt(match[1], 10);

        let previousText = "";

        for (let i = 1; i <= totalRounds; i++) {
          await waitFor(".payout-item-title");

          const current = [...document.querySelectorAll(".payout-item-title")]
            .map(el => el.innerText?.trim() || '')
            .filter(Boolean)
            .join(" | ");

          if (current) previousText = current;

          // PENTING: ambil payout SETIAP ROUND, bukan hanya round terakhir.
          collectAllPayouts();

          if (i < totalRounds) {
            const nextBtn = document.querySelector(".detail-navigation.right");
            if (nextBtn && nextBtn.offsetParent !== null) {
              const stopDefault = (e) => e.preventDefault();
              nextBtn.addEventListener("click", stopDefault, true);
              nextBtn.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
              nextBtn.removeEventListener("click", stopDefault, true);
              await waitForPayoutChange(previousText);
            }
          }
        }
      }

      await collectPayout();

      const hasData =
        data.transaction ||
        data.bet ||
        data.profit ||
        data.symbols.length ||
        data.payouts.length;

      if (hasData) {
        console.log("DATA DIAMBIL:", data);
        chrome.runtime.sendMessage({
          type: "SEND_TO_SHEET",
          payload: data
        });
      } else {
        console.log("Tidak ada data untuk dikirim.");
      }

    } catch (e) {
      console.warn("BET LOGGER ERROR:", e);
      const msg = String(e);
      if (msg.includes('Timeout')) {
        const kode = getKodeTiketFromUrl();
        if (kode) {
          chrome.runtime.sendMessage({
            type: "BET_ERROR",
            kodeTiket: kode,
            error: 'Session Timeout - halaman tidak merespon'
          });
        }
      }
    }
  }

  runWhenReady();
})();
