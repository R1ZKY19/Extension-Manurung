self.addEventListener("unhandledrejection", event => { event.preventDefault(); });

// ================= STORAGE HELPERS =================
async function getData(keys) { return new Promise(r => chrome.storage.local.get(keys, r)); }

async function setData(obj, retries = 2) {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set(obj, () => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve();
      });
    });
  } catch (err) {
    if (retries <= 0 || !err.message?.includes('QuotaBytes')) throw err;
    // Quota exceeded — bersihkan data besar lalu coba lagi
    // Catat log dulu pakai tulis langsung (hindari rekursif via addLog)
    var reason = 'Storage: quota penuh, pembersihan otomatis';
    var { logs = [] } = await new Promise(r => chrome.storage.local.get('logs', r));
    logs.push({ time: Date.now(), message: reason });
    if (logs.length > 100) logs.splice(0, logs.length - 100);
    await new Promise(r => chrome.storage.local.set({ logs }, r));
    // Hapus gambar paling besar
    var keys = await new Promise(r => chrome.storage.local.get(['bgImage', 'decoLeftArr', 'decoRightArr', 'quickNote'], r));
    if (keys.bgImage) await new Promise(r => chrome.storage.local.remove('bgImage', r));
    if ((keys.decoLeftArr?.length || 0) + (keys.decoRightArr?.length || 0) > 0)
      await new Promise(r => chrome.storage.local.remove(['decoLeftArr', 'decoRightArr'], r));
    await setData(obj, retries - 1);
  }
}

// ===== ROWS LOCK =====
// chrome.storage baca-lalu-simpan tidak atomik. Kalau banyak tab (invoice/bet-detail) kirim
// data betting/payout hampir bersamaan, masing-masing baca versi 'rows' yang sama lalu saling
// timpa saat simpan -> update salah satu tab hilang. withRows() mengantrikan setiap
// baca-ubah-simpan supaya tidak ada yang bertabrakan, walau dipanggil dari banyak tab sekaligus.
let rowsLock = Promise.resolve();
function withRows(mutator) {
  const run = rowsLock.then(async () => {
    const { rows = [] } = await getData('rows');
    const result = await mutator(rows);
    await setData({ rows });
    return result;
  });
  rowsLock = run.then(() => {}, () => {}); // tetap lanjut walau ada error, supaya antrian tidak macet permanen
  return run;
}

async function addLog(msg) {
  const { logs = [] } = await getData('logs');
  logs.push({ time: Date.now(), message: msg });
  if (logs.length > 100) logs.splice(0, logs.length - 100);
  await setData({ logs });
}

// Jalankan banyak item dengan jumlah tab paralel terbatas (bukan buka semua sekaligus tanpa batas).
// Begitu satu selesai, slot-nya langsung dipakai item berikutnya — jadi tetap efisien walau
// waktu proses tiap item beda-beda (ada yang cepat ketemu, ada yang nunggu timeout).
async function runWithConcurrency(items, limit, worker, staggerMs) {
  const results = new Array(items.length);
  let nextIndex = 0;
  async function runNext() {
    while (nextIndex < items.length) {
      const current = nextIndex++;
      if (staggerMs) {
        await new Promise(r => setTimeout(r, current * staggerMs));
      }
      results[current] = await worker(items[current], current);
    }
  }
  const lanes = Array.from({ length: Math.min(limit, items.length) }, runNext);
  await Promise.all(lanes);
  return results;
}

// ================= OPEN DASHBOARD =================
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});

// ================= ADMIN URL DETECTION =================
async function detectAdminUrl() {
  const tabs = await chrome.tabs.query({});

  // Prioritas 1: cari tab admin yang sedang membuka transaction-record.html.
  // Ini membuat checker tidak lagi tergantung pada domain lama yang di-hardcode.
  for (const tab of tabs) {
    if (!tab.url) continue;
    try {
      const u = new URL(tab.url);
      if (u.protocol === 'http:' || u.protocol === 'https:') {
        if (u.pathname.includes('/transaction-record.html')) return u.origin;
      }
    } catch (_) {}
  }

  // Prioritas 2: cari tab admin yang membuka keterangan-detail.html.
  for (const tab of tabs) {
    if (!tab.url) continue;
    try {
      const u = new URL(tab.url);
      if (u.protocol === 'http:' || u.protocol === 'https:') {
        if (u.pathname.includes('/keterangan-detail.html')) return u.origin;
      }
    } catch (_) {}
  }

  return null;
}

// ----------------- STATE -----------------
let autoEnabled   = true;
let countdown     = 60;
let intervalTimer = null;
let isRunning     = false;
let queueLastRun  = 0;

let manualRunning       = false;
let manualSafetyTimeout = null;
let manualInterval      = null;

const pendingInvoiceTabs = new Map();

// Pulihkan state setelah service worker restart
(async function restoreState() {
  const saved = await getData('autoEnabled');
  if (saved.autoEnabled !== undefined) autoEnabled = saved.autoEnabled;
})();

// =======================================================
// MANUAL TIMER
// =======================================================
const MAX_CONCURRENT = 10;

function startManualTimer() {
  if (manualInterval) clearInterval(manualInterval);
  manualInterval = setInterval(async () => {
    if (manualRunning) return;
    manualRunning = true;
    if (manualSafetyTimeout) clearTimeout(manualSafetyTimeout);
    manualSafetyTimeout = setTimeout(() => {
      console.warn("Manual force unlock (safety 120s)");
      manualRunning = false;
    }, 120000);
    try {
      const { rows = [] } = await getData('rows');
      const now = Date.now();

      // Auto-retry: rows stuck in CHECKING >= 10 detik — reset biar diproses ulang
      // Skip jika row masih punya pending invoice tab (masih loading)
      const pendingTabRows = new Set();
      for (const entry of pendingInvoiceTabs.values()) pendingTabRows.add(entry.row);
      let needsSave = false;
      for (const row of rows) {
        if (!row.user || !row.kodeTiket) continue;
        if (row.betting && row.payout) continue;
        if (row.manualStatus !== 'CHECKING') continue;
        if (!row.updatedAt || now - row.updatedAt < 10000) continue;
        if (pendingTabRows.has(row.id)) continue; // masih ada tab invoice aktif
        const attempt = (row.autoRetryCount || 0) + 1;
        if (attempt > 5) continue;
        row.autoRetryCount = attempt;
        row.manualStatus = '';
        row.autoCol10 = 'Auto Retry ' + attempt + 'x';
        row.updatedAt = now;
        needsSave = true;
      }
      if (needsSave) {
        await setData({ rows });
        await addLog('Auto Retry: mereset baris yang stuck CHECKING');
      }

      const pending = rows.filter(r =>
        r.user && r.kodeTiket && !r.betting && !r.payout && !r.manualStatus
      );
      if (pending.length === 0) return;
      const origin = await detectAdminUrl();
      const manualUrl = origin + '/transaction-record.html';
      const baseUrl = origin + '/keterangan-detail.html';
      console.log(`Manual: ${pending.length} baris antri via ${origin}`);
      await processManualBatch(pending, manualUrl, baseUrl);
    } catch (err) {
      console.error("Manual timer error:", err);
    } finally {
      if (manualSafetyTimeout) clearTimeout(manualSafetyTimeout);
      manualRunning = false;
    }
  }, 3000);
}

// Manual timer disabled: checking is now started explicitly from the dashboard paste action.

async function startManualImmediate() {
  if (manualRunning) { console.log('Manual: sudah ada batch berjalan, lewati trigger immediate'); return; }
  manualRunning = true;
  if (manualSafetyTimeout) clearTimeout(manualSafetyTimeout);
  manualSafetyTimeout = setTimeout(() => {
    console.warn("Manual force unlock (safety 120s)");
    manualRunning = false;
  }, 120000);
  try {
    const { rows = [] } = await getData('rows');
    const pending = rows.filter(r =>
      r.user && r.kodeTiket && !r.betting && !r.payout && !r.manualStatus
    );
    if (pending.length === 0) return;
    const origin = await detectAdminUrl();
    const manualUrl = origin + '/transaction-record.html';
    const baseUrl = origin + '/keterangan-detail.html';
    console.log(`Manual immediate: ${pending.length} baris via ${origin}`);
    await processManualBatch(pending, manualUrl, baseUrl);
  } finally {
    if (manualSafetyTimeout) clearTimeout(manualSafetyTimeout);
    manualRunning = false;
  }
}

const MANUAL_MAX_CONCURRENT     = 4;     // batas tab pencarian/invoice yang dibuka bersamaan, supaya situs & pembacaan data tidak overload saat baris banyak
const MANUAL_SEARCH_RETRY_MAX   = 1;     // retry solo kalau gagal di tahap cari record transaksi
const INVOICE_TIMEOUT_MS        = 15000; // dinaikkan dari 12000 — beri sedikit lebih banyak waktu saat beberapa tab jalan bersamaan
const INVOICE_RETRY_TIMEOUT_MS  = 20000; // saat retry solo (sendirian, tanpa tab lain mengganggu), kasih waktu lebih lega
const INVOICE_RETRY_MAX         = 1;     // retry solo kalau tab invoice timeout sebelum data betting/payout sampai

async function searchInvoiceUrl(rowData, targetUrl, baseUrl, checkDate) {
  let tab;
  try {
    tab = await chrome.tabs.create({ url: targetUrl, active: false });
    await new Promise((res, rej) => {
      const timer = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        rej(new Error('Tab load timeout'));
      }, 15000);
      function listener(tabId, info) {
        if (tabId === tab.id && info.status === 'complete') {
          clearTimeout(timer);
          chrome.tabs.onUpdated.removeListener(listener);
          res();
        }
      }
      chrome.tabs.onUpdated.addListener(listener);
    });
    const [execResult] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func:   manualPageScript,
      args: [
        String(rowData.user ?? ''),
        String(rowData.kodeTiket ?? ''),
        Boolean(rowData.hasTS),
        String(baseUrl ?? ''),
        Number(rowData.id),
        String(checkDate || "")
      ]
    });
    return execResult.result ?? { row: rowData.id, found: false };
  } catch (err) {
    console.error(`Error row ${rowData.id}:`, err);
    return { row: rowData.id, found: false, error: true };
  } finally {
    if (tab?.id) { try { chrome.tabs.remove(tab.id); } catch (_) {} }
  }
}

async function processManualBatch(rows, targetUrl, baseUrl, checkDate = "") {
  // Mark all as CHECKING
  await withRows(allRows => {
    for (const row of rows) {
      const found = allRows.find(r => r.id === row.id);
      if (found) { found.manualStatus = 'CHECKING'; found.updatedAt = Date.now(); }
    }
  });
  console.log(`Manual: ${rows.length} baris diproses`);

  const resultMap = new Map();
  const firstPass = await runWithConcurrency(rows, MANUAL_MAX_CONCURRENT, rowData => searchInvoiceUrl(rowData, targetUrl, baseUrl, checkDate), 800);
  firstPass.forEach(r => { if (r) resultMap.set(r.row, r); });

  // Retry SOLO (satu per satu, tanpa tab lain mengganggu) untuk baris yang gagal ketemu
  // record transaksinya di percobaan pertama — biasanya cuma gagal karena halaman lambat
  // render saat banyak tab jalan bareng, bukan karena transaksinya benar-benar tidak ada.
  let toRetrySearch = rows.filter(rowData => !(resultMap.get(rowData.id)?.found && resultMap.get(rowData.id)?.url));
  let searchAttempt = 1;
  while (toRetrySearch.length > 0 && searchAttempt <= MANUAL_SEARCH_RETRY_MAX) {
    await addLog(`Manual: retry pencarian ${toRetrySearch.length} baris (percobaan ${searchAttempt}, solo)`);
    for (const rowData of toRetrySearch) {
      const result = await searchInvoiceUrl(rowData, targetUrl, baseUrl, checkDate);
      resultMap.set(rowData.id, result);
    }
    toRetrySearch = toRetrySearch.filter(rowData => !(resultMap.get(rowData.id)?.found && resultMap.get(rowData.id)?.url));
    searchAttempt++;
  }

  const allResults  = rows.map(rowData => resultMap.get(rowData.id) ?? { row: rowData.id, found: false });
  const notFoundRows = allResults.filter(r => !r.found);
  const foundRows    = allResults.filter(r => r.found && r.url);

  if (notFoundRows.length > 0) {
    await withRows(curRows => {
      for (const r of notFoundRows) {
        const row = curRows.find(x => x.id === r.row);
        if (row) { row.manualStatus = 'Betting Not Found'; row.autoCol10 = 'Betting Not Found'; row.updatedAt = Date.now(); }
      }
    });
    await addLog(`Manual: ${notFoundRows.length} baris Betting Not Found`);
  }

  if (foundRows.length > 0) {
    await openInvoiceTabsAndWait(foundRows);
  }
}

async function openInvoiceTab(item, timeoutMs) {
  return new Promise(async outerResolve => {
    let tab;
    try {
      tab = await chrome.tabs.create({ url: item.url, active: false });
      const timer = setTimeout(() => {
        console.warn(`Timeout tab ${tab.id} row ${item.row}`);
        pendingInvoiceTabs.delete(tab.id);
        chrome.tabs.get(tab.id, t => { if (!chrome.runtime.lastError && t) chrome.tabs.remove(tab.id); });
        outerResolve({ row: item.row, ok: false });
      }, timeoutMs);
      pendingInvoiceTabs.set(tab.id, {
        resolve: () => outerResolve({ row: item.row, ok: true }),
        timer,
        row: item.row
      });
    } catch (err) {
      console.error(`Gagal buka invoice row ${item.row}:`, err);
      outerResolve({ row: item.row, ok: false });
    }
  });
}

async function openInvoiceTabsAndWait(foundRows) {
  const firstPass = await runWithConcurrency(foundRows, MANUAL_MAX_CONCURRENT, item => openInvoiceTab(item, INVOICE_TIMEOUT_MS), 400);

  // Retry SOLO (satu per satu, dengan waktu lebih lega) untuk baris yang timeout di percobaan
  // pertama — kalau dicoba sendirian biasanya langsung ketemu, jadi jangan langsung diskip.
  let toRetry = foundRows.filter((item, idx) => !firstPass[idx]?.ok);
  let attempt = 1;
  while (toRetry.length > 0 && attempt <= INVOICE_RETRY_MAX) {
    await addLog(`Manual: retry invoice ${toRetry.length} baris (percobaan ${attempt}, solo)`);
    const stillFailing = [];
    for (const item of toRetry) {
      const result = await openInvoiceTab(item, INVOICE_RETRY_TIMEOUT_MS);
      if (!result.ok) stillFailing.push(item);
    }
    toRetry = stillFailing;
    attempt++;
  }

  if (toRetry.length > 0) {
    await withRows(rows => {
      for (const item of toRetry) {
        const row = rows.find(r => r.id === item.row);
        if (row && row.manualStatus === 'CHECKING') {
          row.manualStatus = 'Betting Not Found';
          row.autoCol10 = 'Betting Not Found';
          row.updatedAt = Date.now();
        }
      }
    });
    await addLog(`Manual: ${toRetry.length} baris tetap Betting Not Found setelah retry`);
  }
}

function manualPageScript(e6, l6, hasTS, baseUrl, rowNumber, checkDate) {
  const xp = path => document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  const setVal = (el, val) => {
    if (!el) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
    if (!setter) return;
    setter.call(el, val);
    el.dispatchEvent(new Event("input",  { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  };
  const waitEl = (xpath, timeout = 8000) => new Promise((resolve, reject) => {
    const el = xp(xpath);
    if (el) return resolve(el);
    let done = false;
    const obs = new MutationObserver(() => {
      if (done) return;
      const el = xp(xpath);
      if (el) { done = true; obs.disconnect(); clearTimeout(t); resolve(el); }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    const t = setTimeout(() => { if (!done) { done = true; obs.disconnect(); reject("Timeout: " + xpath); } }, timeout);
  });
  const waitElSafe = (xpath, timeout = 3000) => new Promise(resolve => {
    const el = xp(xpath);
    if (el) return resolve(el);
    let done = false;
    const obs = new MutationObserver(() => {
      if (done) return;
      const el = xp(xpath);
      if (el) { done = true; obs.disconnect(); clearTimeout(t); resolve(el); }
    });
    obs.observe(document.body, { childList: true, subtree: true });
    const t = setTimeout(() => { if (!done) { done = true; obs.disconnect(); resolve(null); } }, timeout);
  });
  return (async () => {
    try {
      const [inputE6, inputL6] = await Promise.all([
        waitEl('/html/body/div[2]/div[3]/form/div/ul/li[1]/input'),
        waitEl('//*[@id="transactionId"]')
      ]);
      setVal(inputE6, e6);
      setVal(inputL6, l6);
      // Gunakan tanggal yang dipilih di dashboard untuk pencarian transaction-record.
      // Isi startDate dan endDate jika field tersedia.
      if (checkDate) {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
        for (const selector of ['#startDate', '#endDate', 'input[name="startDate"]', 'input[name="endDate"]']) {
          const d = document.querySelector(selector);
          if (d && setter) {
            setter.call(d, checkDate);
            d.dispatchEvent(new Event("input",  { bubbles: true }));
            d.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
      }
      const searchBtn = await waitEl('/html/body/div[2]/div[3]/form/div/div/a[1]');
      searchBtn.click();
      const tabBtn = await waitEl('/html/body/div[2]/div[3]/div[2]/ul/li[2]/a');
      tabBtn.click();
      let detailBtn = await waitElSafe('/html/body/div[2]/div[3]/div[4]/div/table/tbody/tr/td[5]/a', 10000);
      if (!detailBtn) {
        await new Promise(r => setTimeout(r, 2000));
        detailBtn = await waitElSafe('/html/body/div[2]/div[3]/div[4]/div/table/tbody/tr/td[5]/a', 5000);
      }
      if (!detailBtn) return { row: rowNumber, found: false };
      const keteranganEl = document.querySelector('td.dataChange[data-changekey="keterangan"]');
      const keteranganText = keteranganEl?.innerText?.trim() ?? '';
      let gamename = 65;
      if (keteranganText === 'PG-Mahjong Ways 2') { gamename = 74; }
      else if (keteranganText === 'PG-Mahjong Ways') { gamename = 65; }
      const invoiceUrl = `${baseUrl}?invoice=${encodeURIComponent(l6 + '-' + l6 + '-106-0')}&status=03&periode=null&gamename=${gamename}&tablekey=7`;
      return { row: rowNumber, found: true, url: invoiceUrl };
    } catch (err) {
      console.warn(`manualPageScript error row ${rowNumber}:`, err);
      return { row: rowNumber, found: false };
    }
  })();
}

// Hadiah resmi ditentukan dari BET + PAYOUT, bukan dari angka Profit mentah di halaman.
function parseMoneyValue(value) {
  let s = String(value ?? '').trim().replace(/[^0-9.,-]/g, '');
  if (!s) return null;
  const negative = s.startsWith('-');
  s = s.replace(/-/g, '');
  const lastDot = s.lastIndexOf('.');
  const lastComma = s.lastIndexOf(',');
  if (lastDot >= 0 && lastComma >= 0) {
    const pos = Math.max(lastDot, lastComma);
    const digits = s.length - pos - 1;
    if (digits === 3) s = s.replace(/[.,]/g, '');
    else s = s.slice(0, pos).replace(/[.,]/g, '') + '.' + s.slice(pos + 1).replace(/[.,]/g, '');
  } else if (lastDot >= 0 || lastComma >= 0) {
    const pos = Math.max(lastDot, lastComma);
    const digits = s.length - pos - 1;
    if (digits === 3) s = s.replace(/[.,]/g, '');
    else if (lastComma >= 0) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/,/g, '');
  }
  const n = Number(s);
  return Number.isFinite(n) ? (negative ? -n : n) : null;
}

function rewardFromBetPayout(bet, payout) {
  const b = parseMoneyValue(bet);
  const m = String(payout ?? '').match(/x\s*(3|4|5)\b/i);
  const x = m ? Number(m[1]) : null;
  if (!Number.isFinite(b) || !x) return null;
  const tiers = [
    [1600, 2000, {3:15000,4:30000,5:75000}],
    [4000, 8000, {3:35000,4:70000,5:140000}],
    [10000, 18000, {3:50000,4:100000,5:200000}],
    [20000, 1000000, {3:100000,4:200000,5:400000}]
  ];
  const tier = tiers.find(t => b >= t[0] && b <= t[1]);
  return tier ? tier[2][x] : null;
}

// ================= BET DATA -> DASHBOARD STORAGE =================
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== "SEND_TO_SHEET") return;
  const tabId = sender.tab?.id;
  if (!tabId) return;
  handleBetData(msg.payload, tabId);
});

// Jika halaman Bet Details gagal memuat data utama, tandai hasil sebagai TIDAK SESUAI
// agar baris tidak berhenti di status MENGECEK/MENUNGGU.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== 'BET_ERROR') return;
  const kode = String(msg.kodeTiket || '').trim();
  if (!kode) return;
  withRows(rows => {
    const row = rows.find(r => {
      const k = String(r.kodeTiket || '').replace(/\s+/g, '').trim();
      const q = kode.replace(/\s+/g, '').trim();
      return k === q || k.startsWith(q) || q.startsWith(k.split('-')[0]);
    });
    if (row) {
      row.manualStatus = 'TIDAK SESUAI';
      row.autoCol10 = msg.error || 'BET / PAYOUT / PROFIT TIDAK LENGKAP';
      row.updatedAt = Date.now();
    }
  }).catch(err => console.error('BET_ERROR handler:', err));
});

async function handleBetData(payload, tabId) {
  try {
    const foundRow = await withRows(rows => {
      const searchId = (payload.transaction || '').toString().trim();
      if (!searchId || searchId.length < 3) return null; // cegah data kosong/parsial timpa baris lain
      let match = null;
      for (const row of rows) {
        if (!row.kodeTiket) continue;
        const tStr = row.kodeTiket.toString().replace(/\s+/g, '').trim();
        if (tStr === searchId || tStr.startsWith(searchId) || tStr.includes(searchId) || searchId.startsWith(tStr.split("-")[0])) {
          match = row; break;
        }
      }
      if (match) {
        if (payload.bet) match.betting = payload.bet;
        if (payload.payouts?.length) match.payout = payload.payouts.filter(p => /^X[345]$/i.test(String(p).trim())).join(" | ");
        if (payload.transaction) match.transactionId = payload.transaction;
        if (payload.profit) match.profit = payload.profit;
        if (payload.symbols?.length) match.symbols = payload.symbols;
        if (payload.payouts?.length) match.payoutDetail = payload.payouts.filter(p => /^X[345]$/i.test(String(p).trim()));

        // Final hanya jika BET + PAYOUT + PROFIT semuanya tersedia.
        // Jika ada yang hilang, jangan pernah dianggap selesai/SESUAI.
        const hasBet = Boolean(String(match.betting || '').trim());
        const hasPayout = Boolean(String(match.payout || '').trim());
        const expectedReward = rewardFromBetPayout(match.betting, match.payout);
        const hasProfitHadiah = expectedReward !== null;
        match.autoRetryCount = 0;
        match.manualStatus = (hasBet && hasPayout && hasProfitHadiah) ? '' : 'TIDAK SESUAI';
        match.autoCol10 = (hasBet && hasPayout && hasProfitHadiah) ? '' : 'BET / PAYOUT / PROFIT-HADIAH TIDAK LENGKAP';
        match.updatedAt = Date.now();
      }
      return match ? { ...match } : null; // salin keluar supaya aman dipakai di luar lock
    });

    if (foundRow) {
      await addLog(`Manual: data bet row #${foundRow.id} tersimpan (${foundRow.transactionId})`);

    }
  } catch (err) {
    console.error('handleBetData error:', err);
  } finally {
    const pending = pendingInvoiceTabs.get(tabId);
    if (pending) {
      clearTimeout(pending.timer);
      pendingInvoiceTabs.delete(tabId);
      pending.resolve();
      // Hanya tutup tab yang dibuka otomatis, bukan tab manual user
      chrome.tabs.get(tabId, t => { if (!chrome.runtime.lastError && t) chrome.tabs.remove(tabId); });
    }
  }
}

chrome.tabs.onRemoved.addListener(tabId => {
  const pending = pendingInvoiceTabs.get(tabId);
  if (pending) { clearTimeout(pending.timer); pendingInvoiceTabs.delete(tabId); pending.resolve(); }
});

// ================= PASTE CHECKER FROM DASHBOARD =================
function parsePastedRows(text) {
  const lines = String(text || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean);

  const parsed = [];
  for (const line of lines) {
    // Supports: Name | TransactionId, Name TransactionId, and tabs.
    const parts = line.split(/\s*\|\s*|\t+/).map(s => s.trim()).filter(Boolean);
    let user = '';
    let kodeTiket = '';

    if (parts.length >= 2) {
      user = parts[0];
      kodeTiket = parts[1];
    } else {
      const tokens = line.split(/\s+/).filter(Boolean);
      if (tokens.length >= 2) {
        kodeTiket = tokens.pop();
        user = tokens.join(' ');
      }
    }

    if (!user || !kodeTiket) {
      parsed.push({ invalid: true, raw: line });
      continue;
    }

    const hasTS = /\sTS$/i.test(user);
    user = user.replace(/\sTS$/i, '').trim();
    parsed.push({ user, kodeTiket, hasTS, raw: line });
  }
  return parsed;
}

async function startXlsxCheck(items, checkDate = '', limit = 10) {
  if (manualRunning) return { ok: false, error: 'Pengecekan masih berjalan.' };

  // Batasi batch di background juga, supaya limit tidak bisa terlewati walaupun
  // pemanggil mengirim lebih banyak data dari yang diminta dashboard.
  const requestedLimit = Math.max(1, Math.min(1000, Number(limit) || 10));
  const valid = (Array.isArray(items) ? items : []).filter(x =>
    x && String(x.user || '').trim() && String(x.kodeTiket || '').trim()
  ).slice(0, requestedLimit);
  if (!valid.length) return { ok: false, error: 'Tidak ada USER ID + KODE TIKET yang valid.' };

  manualRunning = true;
  const baseId = Date.now();
  const rows = valid.map((item, idx) => ({
    id: baseId + idx,
    user: String(item.user).trim(),
    kodeTiket: String(item.kodeTiket).trim(),
    hasTS: false,
    checkDate: String(checkDate || ''),
    createdAt: Date.now(),
    // Sengaja CHECKING sejak row dibuat agar dashboard langsung menampilkan
    // status MENGECEK, tanpa menunggu seluruh pipeline selesai.
    manualStatus: 'CHECKING',
    autoStatus: '',
    sourceRaw: `${item.user} ${item.kodeTiket}`,
    checkBatch: baseId
  }));

  try {
    const stored = await getData('rows');
    const oldRows = Array.isArray(stored?.rows) ? stored.rows : [];
    await setData({ rows: [...oldRows, ...rows], nextRowId: baseId + rows.length });
    await addLog(`XLSX Check: ${rows.length} data mulai dicek, tanggal ${checkDate || 'default'}`);

    // Balas dashboard segera setelah row dibuat. Pipeline berjalan di background
    // sehingga tabel langsung terlihat sebagai MENGECEK.
    const origin = await detectAdminUrl();
    if (!origin) {
      await withRows(cur => {
        for (const item of rows) {
          const r = cur.find(x => x.id === item.id);
          if (r) {
            r.manualStatus = 'ADMIN URL NOT FOUND';
            r.autoCol10 = 'Buka dan login ke /transaction-record.html terlebih dahulu.';
            r.updatedAt = Date.now();
          }
        }
      });
      manualRunning = false;
      return { ok: false, error: 'Buka dan login ke halaman /transaction-record.html terlebih dahulu.' };
    }

    const manualUrl = origin + '/transaction-record.html';
    const baseUrl = origin + '/keterangan-detail.html';
    void (async () => {
      try {
        await processManualBatch(rows, manualUrl, baseUrl, checkDate);
      } catch (err) {
        console.error('XLSX background pipeline error:', err);
        await withRows(cur => {
          for (const item of rows) {
            const r = cur.find(x => x.id === item.id);
            if (r && r.manualStatus === 'CHECKING') {
              r.manualStatus = 'TIDAK SESUAI';
              r.autoCol10 = 'PENGECEKAN GAGAL';
              r.updatedAt = Date.now();
            }
          }
        });
      } finally {
        manualRunning = false;
      }
    })();

    return { ok: true, batchId: baseId, total: rows.length, date: checkDate, previous: oldRows.length };
  } catch (err) {
    manualRunning = false;
    throw err;
  }
}

// Kompatibilitas jika ada pesan lama dari versi sebelumnya.
async function startPasteCheck(text, append = false) {
  const parsed = parsePastedRows(text).filter(x => !x.invalid)
    .map(x => ({ user: x.user, kodeTiket: x.kodeTiket }));
  return startXlsxCheck(parsed, '', parsed.length || 10);
}

async function retryXlsxCheck(rowId, checkDate = '') {
  if (manualRunning) return { ok: false, error: 'Pengecekan masih berjalan.' };
  const stored = await getData('rows');
  const rows = Array.isArray(stored?.rows) ? stored.rows : [];
  const row = rows.find(r => Number(r.id) === Number(rowId));
  if (!row || !row.user || !row.kodeTiket) return { ok: false, error: 'Data transaksi tidak ditemukan.' };
  manualRunning = true;
  try {
    await withRows(cur => {
      const r = cur.find(x => Number(x.id) === Number(rowId));
      if (r) {
        r.manualStatus = 'CHECKING';
        r.betting = ''; r.payout = ''; r.profit = ''; r.transactionId = '';
        r.autoCol10 = ''; r.updatedAt = Date.now();
        if (checkDate) r.checkDate = String(checkDate);
      }
    });
    const origin = await detectAdminUrl();
    if (!origin) {
      await withRows(cur => { const r=cur.find(x=>Number(x.id)===Number(rowId)); if(r){r.manualStatus='ADMIN URL NOT FOUND';r.updatedAt=Date.now();} });
      return { ok:false,error:'Buka dan login ke /transaction-record.html terlebih dahulu.' };
    }
    const manualUrl = origin + '/transaction-record.html';
    const baseUrl = origin + '/keterangan-detail.html';
    await processManualBatch([{...row, checkDate: checkDate || row.checkDate || ''}], manualUrl, baseUrl, checkDate || row.checkDate || '');
    return { ok:true,rowId:Number(rowId) };
  } finally { manualRunning = false; }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'RETRY_XLSX_CHECK') {
    retryXlsxCheck(Number(msg.rowId), msg.checkDate || '')
      .then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err?.message || err) }));
    return true;
  }
  if (msg.type === 'START_XLSX_CHECK') {
    startXlsxCheck(msg.items, msg.checkDate || '', Number(msg.limit) || 10)
      .then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err?.message || err) }));
    return true;
  }
  if (msg.type === 'START_PASTE_CHECK') {
    startPasteCheck(msg.text, Boolean(msg.append))
      .then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err?.message || err) }));
    return true;
  }
});

// ================= TRIGGER PIPELINE FROM DASHBOARD =================
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === "TRIGGER_MANUAL") { startManualImmediate(); }
});

// ================= INJECT CONTENT.JS =================
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.title?.trim() === "Bet Details") {
    chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  }
});

// ================= ALARMS =================
chrome.runtime.onInstalled.addListener(() => {
  // Initialize storage if empty
  getData('rows').then(({ rows }) => {
    if (!rows) setData({ rows: [] });
  });
  getData('nextRowId').then(({ nextRowId }) => {
    if (!nextRowId) setData({ nextRowId: 1 });
  });
});
chrome.runtime.onStartup.addListener(() => {
});
