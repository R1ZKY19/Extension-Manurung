export const STORAGE_KEYS = {
  CONFIG: 'config',
  ROWS: 'rows',
  LOGS: 'logs',
  NEXT_ID: 'nextRowId'
};
