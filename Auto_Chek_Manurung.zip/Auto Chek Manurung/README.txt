SYAFIRA Transaction Checker v3

ALUR:
Paste -> /transaction-record.html -> cari record -> keterangan-detail.html -> Bet Details -> hasil tampil di Dashboard.

PERUBAHAN:
- /tickets dihapus dari pipeline.
- /history dihapus dari pipeline.
- Tidak ada lagi form bonus/scatter dan proses submit ke /tickets.
- Tidak ada pengiriman data ke Google Sheet.
- Dashboard hanya menampilkan hasil pengecekan transaksi.
- Kolom Balance, Spin, dan Free Spin dihapus dari dashboard.
- Profit / Hadiah di dashboard menampilkan nilai PROFIT aktual yang dibaca dari halaman Bet Details, bukan hasil kalkulasi buatan dashboard.
- Format input:
  Nama TransactionID
  atau
  Nama | TransactionID

INSTAL:
1. chrome://extensions
2. Developer mode ON
3. Load unpacked
4. Pilih folder hasil ekstrak.
5. Login ke admin dan buka /transaction-record.html.
6. Klik icon SYAFIRA untuk dashboard.

- Profit / Hadiah dihitung berdasarkan BET aktual + PAYOUT multiplier aktual dengan tier hadiah: 1.600-2.000 (x3=15.000, x4=30.000, x5=75.000); 4.000-8.000 (x3=35.000, x4=70.000, x5=140.000); 10.000-18.000 (x3=50.000, x4=100.000, x5=200.000); 20.000-1.000.000 (x3=100.000, x4=200.000, x5=400.000).


3.0.4: Payout dibatasi hanya X3, X4, X5. X2 dan multiplier lain diabaikan.
