// ─── HELPERS ──────────────────────────────────────────────
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

const esc = v => String(v ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c)
);

const norm = v => String(v ?? '').trim().replace(/\s+/g, '').toLowerCase();

const money = v => {
    let s = String(v ?? '').trim().replace(/[^0-9.,-]/g, '');
    if (!s) return null;
    const negative = s.startsWith('-');
    s = s.replace(/-/g, '');

    const lastDot = s.lastIndexOf('.');
    const lastComma = s.lastIndexOf(',');
    if (lastDot >= 0 && lastComma >= 0) {
        const decimalPos = Math.max(lastDot, lastComma);
        const decimalDigits = s.length - decimalPos - 1;
        if (decimalDigits === 3) s = s.replace(/[.,]/g, '');
        else s = s.slice(0, decimalPos).replace(/[.,]/g, '') + '.' + s.slice(decimalPos + 1).replace(/[.,]/g, '');
    } else if (lastDot >= 0 || lastComma >= 0) {
        const pos = Math.max(lastDot, lastComma);
        const digitsAfter = s.length - pos - 1;
        if (digitsAfter === 3) s = s.replace(/[.,]/g, '');
        else if (lastComma >= 0) s = s.replace(/\./g, '').replace(',', '.');
        else s = s.replace(/,/g, '');
    }
    const n = Number(s);
    return Number.isFinite(n) ? (negative ? -n : n) : null;
};

const formatBet = v => {
    const n = money(v);
    return n === null ? '' : new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(n);
};

const payoutLastX = v => {
    const m = String(v ?? '').match(/\bx\s*(3|4|5)\b/gi);
    return m?.length ? 'X' + m[m.length - 1].replace(/[^345]/g, '') : '';
};

function isBetMatch(x, r) {
    if (!r) return false;
    const xb = money(x['BETTING']);
    const rb = money(r.betting);
    return xb !== null && rb !== null && xb === rb;
}

function rewardFor(bet, payout) {
    const b = money(bet);
    const pm = String(payoutLastX(payout) || '').match(/X\s*(\d+(?:[.,]\d+)?)/i);
    const x = pm ? Number(pm[1].replace(',', '.')) : null;
    if (b === null || !x || ![3, 4, 5].includes(x)) return null;
    const tiers = [
        { min: 1600, max: 2000, v: { 3: 15000, 4: 30000, 5: 75000 } },
        { min: 4000, max: 8000, v: { 3: 35000, 4: 70000, 5: 140000 } },
        { min: 10000, max: 18000, v: { 3: 50000, 4: 100000, 5: 200000 } },
        { min: 20000, max: 1000000, v: { 3: 100000, 4: 200000, 5: 400000 } }
    ];
    const t = tiers.find(t => b >= t.min && b <= t.max);
    return t ? t.v[x] : null;
}

function isKoinMatch(x, r) {
    const expected = money(x['KOIN']);
    const reward = rewardFor(r?.betting, r?.payout);
    if (expected === null || reward === null) return true;
    return expected === reward;
}

function resultFor(x) {
    const k = norm(x['KODE TIKET']);
    return cacheRows.find(r => norm(r.kodeTiket) === k) || null;
}

function statusFor(x, r) {
    if (!r) return ['MENUNGGU', 'wait'];
    if (r.manualStatus === 'CHECKING') return ['MENGECEK', 'wait'];
    if (r.manualStatus === 'Betting Not Found' || r.manualStatus === 'ADMIN URL NOT FOUND')
        return ['TIDAK DITEMUKAN', 'bad'];
    const reward = rewardFor(r.betting, r.payout);
    const complete = Boolean(String(r.betting || '').trim()) &&
        Boolean(String(r.payout || '').trim()) &&
        reward !== null;
    if (r.manualStatus === 'TIDAK SESUAI') return ['TIDAK SESUAI', 'bad'];
    if (complete) {
        const ok = isBetMatch(x, r) && isKoinMatch(x, r);
        return [ok ? 'SESUAI' : 'TIDAK SESUAI', ok ? 'ok' : 'bad'];
    }
    if (r.manualStatus) return ['TIDAK SESUAI', 'bad'];
    return ['MENGECEK', 'wait'];
}

function retryable(r) {
    const st = String(r?.manualStatus || '').toUpperCase();
    return !r || st.includes('NOT FOUND') || st.includes('ERROR') ||
        st.includes('TIMEOUT') || st.includes('FAILED') ||
        st.includes('GAGAL') || st.includes('ADMIN URL');
}

// ─── STATE ────────────────────────────────────────────────
let busy = false;
let page = 1;
const pageSize = 100;
let cacheXlsx = [];
let cacheRows = [];
const body = $('#resultsBody');
const filter = $('#filter');

// ─── RENDER ───────────────────────────────────────────────
function render() {
    const q = filter.value.trim().toLowerCase();
    const filtered = cacheXlsx.filter(x =>
        `${x['USER ID'] || ''} ${x['KODE TIKET'] || ''}`.toLowerCase().includes(q)
    );
    const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
    page = Math.min(page, pages);
    const shown = filtered.slice((page - 1) * pageSize, page * pageSize);

    if (shown.length) {
        body.innerHTML = shown.map(x => {
            const r = resultFor(x);
            const [v, cls] = statusFor(x, r);
            const px = r?.payout ? payoutLastX(r.payout) : '-';
            const reward = rewardFor(r?.betting, r?.payout);
            const actualProfit = reward !== null ? formatBet(reward) : '-';
            const currentStatus = v;
            // Semua hasil TIDAK SESUAI dapat dicek ulang. Status error/not-found
            // juga tetap menyediakan tombol retry. MENGECEK/SESUAI tidak perlu retry.
            const isRetry = r && (currentStatus === 'TIDAK SESUAI' || retryable(r));
            return `<tr>
                <td>${esc(x['USER ID'])}</td>
                <td class="code">${esc(x['KODE TIKET'])}</td>
                <td>${esc(formatBet(x['BETTING']) || '-')}</td>
                <td>${esc(formatBet(x['KOIN']) || '-')}</td>
                <td>${esc(r ? formatBet(r.betting) : '-')}</td>
                <td>${esc(px)}</td>
                <td>${esc(actualProfit)}</td>
                <td><span class="badge ${cls}">${v}</span></td>
                <td>${isRetry ? `<button class="retry-btn" data-id="${r.id}">↻ Cek Ulang</button>` : '-'}</td>
            </tr>`;
        }).join('');
    } else {
        body.innerHTML = `<tr class="empty"><td colspan="9">${cacheXlsx.length ? 'Tidak ada data yang cocok.' : 'Belum ada data XLSX.'}</td></tr>`;
    }

    // Stats
    $('#xlsxTotal').textContent = cacheXlsx.length.toLocaleString('id-ID');
    const checked = cacheXlsx.filter(x => resultFor(x));
    const good = checked.filter(x => statusFor(x, resultFor(x))[0] === 'SESUAI');
    const bad = checked.filter(x => ['TIDAK DITEMUKAN', 'TIDAK SESUAI'].includes(statusFor(x, resultFor(x))[0]));
    $('#done').textContent = checked.length.toLocaleString('id-ID');
    $('#match').textContent = good.length.toLocaleString('id-ID');
    $('#mismatch').textContent = bad.length.toLocaleString('id-ID');

    // Pager
    $('#pageInfo').textContent = `Halaman ${filtered.length ? page : 0} / ${pages}`;
    $('#prevPage').disabled = page <= 1;
    $('#nextPage').disabled = page >= pages;

    // Retry buttons
    document.querySelectorAll('.retry-btn').forEach(btn => {
        btn.onclick = async () => {
            if (busy) return;
            const id = Number(btn.dataset.id);
            const r = cacheRows.find(x => x.id === id);
            if (!r) return;
            busy = true;
            btn.disabled = true;
            btn.textContent = '⏳ ...';
            try {
                const res = await chrome.runtime.sendMessage({
                    type: 'RETRY_XLSX_CHECK',
                    rowId: id,
                    checkDate: $('#checkDate').value || yesterday()
                });
                if (!res?.ok) throw Error(res?.error || 'Gagal cek ulang');
                toast('Cek ulang dimulai');
                await load();
            } catch (e) {
                toast(e.message || 'Gagal cek ulang');
            } finally {
                busy = false;
                btn.disabled = false;
                btn.textContent = '↻ Cek Ulang';
            }
        };
    });
}

// ─── LOAD ──────────────────────────────────────────────────
async function load() {
    try {
        const d = await chrome.storage.local.get(['rows', 'xlsxRows']);
        cacheRows = d.rows || [];
        cacheXlsx = d.xlsxRows || [];
    } catch (_) {
        cacheRows = [];
        cacheXlsx = [];
    }
    render();
    detectAdmin();
    updateInfo();
}

// ─── ADMIN DETECT ──────────────────────────────────────────
async function detectAdmin() {
    try {
        const tabs = await chrome.tabs.query({});
        const ok = tabs.some(t => {
            try { return /\/transaction-record\.html/i.test(new URL(t.url || '').pathname); } catch { return false; }
        });
        const el = $('#adminStatus');
        el.classList.toggle('ok', ok);
        el.innerHTML = `<span></span>${ok ? '✅ Admin terdeteksi' : '⚠️ Admin belum terdeteksi'}`;
        $('#hint').innerHTML = ok ?
            '✅ Siap. Klik <b>Mulai Cek</b>, SYAFIRA akan membaca USER ID + KODE TIKET dari XLSX otomatis.' :
            '⚠️ Buka dan login ke <b>/transaction-record.html</b> terlebih dahulu.';
    } catch (_) {
        // fallback
    }
}

function updateInfo() {
    if (cacheXlsx.length) {
        $('#xlsxInfo').textContent = `${cacheXlsx.length.toLocaleString('id-ID')} data XLSX siap dicek.`;
    } else {
        $('#xlsxInfo').textContent = 'Belum ada XLSX.';
    }
}

// ─── TOAST ──────────────────────────────────────────────────
function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove('show'), 2600);
}

// ─── YESTERDAY ─────────────────────────────────────────────
function yesterday() {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
}

// ─── EVENTS ─────────────────────────────────────────────────

// Import XLSX
$('#xlsxInput').onchange = async () => {
    const f = $('#xlsxInput').files?.[0];
    if (!f) return;
    try {
        let parsed;
        if (typeof window.SYAFIRA_XLSX !== 'undefined' && window.SYAFIRA_XLSX.parseXlsxFile) {
            parsed = await window.SYAFIRA_XLSX.parseXlsxFile(f);
        } else if (typeof XLSX !== 'undefined') {
            const data = await f.arrayBuffer();
            const workbook = XLSX.read(data, { type: 'array' });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const json = XLSX.utils.sheet_to_json(sheet);
            parsed = { rows: json };
        } else {
            throw new Error('XLSX parser tidak tersedia. Pastikan library XLSX sudah dimuat.');
        }
        const rows = (parsed.rows || []).map(x => ({
            'USER ID': String(x['USER ID'] ?? '').trim(),
            'KODE TIKET': String(x['KODE TIKET'] ?? '').trim(),
            'BETTING': String(x['BETTING'] ?? '').trim(),
            'KOIN': String(x['KOIN'] ?? '').trim()
        })).filter(x => x['USER ID'] && x['KODE TIKET']);
        await chrome.storage.local.set({ xlsxRows: rows });
        cacheXlsx = rows;
        page = 1;
        updateInfo();
        render();
        toast(`✅ Import ${rows.length.toLocaleString('id-ID')} data`);
    } catch (e) {
        toast('❌ ' + (e.message || 'Gagal membaca XLSX'));
    }
    $('#xlsxInput').value = '';
};

// Clear XLSX
$('#clearXlsx').onclick = async () => {
    try {
        await chrome.storage.local.remove('xlsxRows');
        cacheXlsx = [];
        page = 1;
        updateInfo();
        render();
        toast('🗑️ Data XLSX dihapus');
    } catch (e) {
        toast('❌ ' + (e.message || 'Gagal menghapus XLSX'));
    }
};

// Clear results
$('#clearBtn').onclick = async () => {
    try {
        await chrome.storage.local.set({ rows: [] });
        cacheRows = [];
        page = 1;
        render();
        $('#lastRun').textContent = 'Hasil pengecekan dibersihkan.';
        toast('🧹 Hasil pengecekan dibersihkan');
    } catch (e) {
        toast('❌ ' + (e.message || 'Gagal membersihkan hasil'));
    }
};

// Date default
$('#checkDate').value = yesterday();

// Check button
$('#checkBtn').onclick = async () => {
    if (busy) return;
    if (!cacheXlsx.length) return toast('📂 Import XLSX terlebih dahulu.');
    const limit = Math.max(1, Math.min(1000, Number($('#checkLimit').value) || 10));
    const checkDate = $('#checkDate').value || yesterday();
    const pending = cacheXlsx.filter(x => {
        const k = norm(x['KODE TIKET']);
        return k && String(x['USER ID'] || '').trim() && !resultFor(x);
    }).slice(0, limit);
    if (!pending.length) return toast('✅ Semua data XLSX sudah dicek.');
    busy = true;
    const btn = $('#checkBtn');
    btn.disabled = true;
    btn.textContent = '⏳ Mengecek...';
    try {
        const items = pending.map(x => ({ user: x['USER ID'], kodeTiket: x['KODE TIKET'] }));
        const res = await chrome.runtime.sendMessage({
            type: 'START_XLSX_CHECK',
            items,
            checkDate,
            limit
        });
        if (!res?.ok) throw Error(res?.error || 'Pengecekan gagal');
        $('#lastRun').textContent = `Batch #${res.batchId} • ${res.total} data • tanggal ${checkDate}`;
        toast(`🚀 Mulai cek ${res.total} data`);
        await load();
    } catch (e) {
        toast('❌ ' + (e.message || 'Pengecekan gagal'));
    } finally {
        busy = false;
        btn.disabled = false;
        btn.textContent = '▶ Mulai Cek';
    }
};

// Filter
filter.oninput = () => { page = 1;
    render(); };

// Pager
$('#prevPage').onclick = () => { if (page > 1) { page--;
        render(); } };
$('#nextPage').onclick = () => { page++;
    render(); };

// Storage changes
chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    let needRender = false;
    if (changes.rows) { cacheRows = changes.rows.newValue || [];
        needRender = true; }
    if (changes.xlsxRows) { cacheXlsx = changes.xlsxRows.newValue || [];
        updateInfo();
        needRender = true; }
    if (needRender) render();
});

// Periodic admin check
setInterval(detectAdmin, 5000);

// ─── BOOT ──────────────────────────────────────────────────
load();